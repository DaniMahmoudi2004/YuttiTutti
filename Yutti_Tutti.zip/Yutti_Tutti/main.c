#include "headers.h"
#include "order.c"
#include "IO.c"

int main () {
    printf("WELCOME TO YUTTI TUTTI!\n");
    post_list head;
    post_list* header = &head;
    header->next = NULL;
    char* username = NULL;
    char** line = (char**)calloc(3, sizeof(char*));
        if (!line) {
            printf("Something went wrong!\n");
            return -1;
        }
    int order_num = -1;
    char c = 'A';
    int k = 0;
    while(TRUE) {
        printf("Please type your order!\n");
        printf("signup <user name> <password>\n");
        printf("login <user name> <password>\n");
        printf("post <text>\n");
        printf("like <user name> <post ID>\n");
        printf("logout\n");
        printf("delete <post_id>\n");
        printf("info\n");
        printf("find_user <username>\n");
        printf("end\n");

        while(c != EOL) {
            c = 'A';   
            int i = 1;
            while (c != EOS && c != EOL) {
                c = getchar(); 
                if (c != EOS && c != EOL) {       
                    line[k] = (char*)realloc(line[k], (i+1) * sizeof(char));
                    if (!line[k]) {
                        printf("Something went wrong!\n");
                        break;
                    }
                    line[k][i-1] = c;
                }
                i++;
            }
            line[k][i-1] = '\0';
            k++;
        }
        c = 'A';
        order_num = order_type(line[0]);
        if (username != NULL) {
            switch (order_num) {
                case -1:
                    printf("The input was incorrect!\n");
                    break;
                case 0: 
                case 1:
                    printf("You have to logout first\n");
                    break;
                case 2:
                    post(line[1], username, header);
                    break;
                case 3:
                    like(atol(line[2]), line[1], username, header);
                    break;
                case 4:
                    if (logout(username)) {
                        username = NULL;
                    }
                    break;
                case 5:
                    delete(atol(line[1]), header, username);
                    break;
                case 6:
                    info(username, header);
                    break;
                case 7:
                    find_user(line[1], header);
                    break;
                case 8:
                    printf("HAVE A GOOD TIME!");
                    getchar();
                    return 0;
                default:
                    printf("Something went wrong!\n");
                    break;
            }
        }
        else {
            switch(order_num) {
                case -1:
                    printf("The input was incorrect!\n");
                    break;
                case 0: 
                    signup(line[1], line[2], header);
                    break;
                case 1:
                    if (login(line[1], line[2], header, username)) {
                        username = (char*)calloc(strlen(line[1]) + 1, sizeof(char));
                        if (!username) {
                            printf("Something went wrong!\n");
                            break;
                        }
                        strcpy(username, line[1]);
                    }
                    break;
                case 8:
                    return 0;
                    break;
                default:
                    printf("You have to login first!\n");
                    break;
            }
        }
        for (int t = 0; t < 3; t++) {
            free(line[t]);
        }
        free(line);
        save(header);
    }
}