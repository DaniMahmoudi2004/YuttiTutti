#include "headers.h"
int order_type (char* order) {
    // finds out the order by a number between 0 to 8
    // and -1 for unknown order
    char *order_list[9];
    order_list[0] = "signup";
    order_list[1] = "login"; 
    order_list[2] = "post";
    order_list[3] = "like";
    order_list[4] = "logout";
    order_list[5] = "delete";
    order_list[6] = "info";
    order_list[7] = "find_user";
    order_list[8] = "end";
    for (int i = 0; i < ORDER_NUM; i ++) {
        if (compstr(order, order_list[i])) {
            return i;
            break;
        }
    }
    return -1;
}

int ID (post_list* header, char* user) {
    // gives the ID of a user
    post_list* ptr = header;
    while (ptr != NULL) {
        if (ptr->like == -1 && compstr(ptr->user, user)) {
            return ptr->id;
        }
        ptr = ptr->next;
    }
}

int signup (char* user, char* password, post_list* header) {
    // saves the account by the name and the password in the head of every section
    // of the linked list known by like = -1
    int id;
    post_list* ptr = header;
    if (ptr->next == NULL) {
        id = 0;
    }
    else {
        while(ptr->next != NULL) {
            if (ptr->like == -1) {
                id ++;
            }
            if (compstr(ptr->user, user)) {
                printf("This username is already choosed!\n");
                return 0;
            }
            ptr = ptr->next;
        }
    }
    post_list* new = (post_list*)malloc(sizeof(post_list));
    new->user = (char*)malloc(strlen(user));
    strcpy(new->user, user);
    new->post = (char*)malloc(strlen(password));
    strcpy(new->post, password);
    new->like = -1;
    new->post_ID = 0;
    new->id = id;
    new->next = NULL;
    ptr->next = new;
    

    return 1;
}

int login (char* name, char* password, post_list* header, char* username) {
    // saves the loging in by saving the user's name in char* usernamey 
    // by giving the right username and password
    post_list* ptr = header->next;
    int counter = 0;
    while (ptr != NULL) {
        if (!strcmp(ptr->user, name)) {
            counter = 1;
            if (ptr->like == -1 && compstr(ptr->post, password)) {
                counter = 2;
                printf("You loged in as ");
                printstr(name);
                printf("!\n");
                return 1;
            }
        }
        ptr = ptr->next;
    }
    if (counter == 0) {
        printf("The username is invalid!\n");
    }
    if (counter == 1) {
        printf("The password is invalid!\n");
    }
    return 0;
}

int post (char* post, char* username, post_list* header) {
    // creates a post in the end of user's list and saves largest post_ID + 1
    // in the post_ID box.
    post_list* ptr = header->next;
    int counter = 0;
    while (ptr->next != NULL) {
        if (compstr(ptr->user, username) && !compstr(ptr->next->user, username)) {
           counter = 1;
           if (ptr->like == -1) {
            counter = 2;
           }
           break;
        }
        ptr = ptr->next;
    }
    if (compstr(ptr->user, username) && ptr->next == NULL) {
        counter = 1;
        if (ptr->like == -1) {
            counter = 2;
        }
    }
    if (counter == 0) {
        printf("The username is invalid!\n");
        return 0;
    }
    else {
        post_list* new = (post_list*)malloc(sizeof(post_list));
        copystr(new->post, post);
        new->like = 0;
        copystr(new->user, username);
        if (counter == 1) {
            new->post_ID = ptr->post_ID + 1;
        }
        else {
            new->post_ID = 0;
        }
        new->next = ptr->next;
        ptr->next = new;
        new->like_list = (int*)malloc(sizeof(int));
        new->like_list[0] = 0;
        return 1;
    }
}

int like (int post_ID, char* name, char* username, post_list* header) {
    // finds the post by geting the name and post_ID and likes it if the user didn't yet
    post_list* ptr = header->next;
    int counter = 0;
    int id;
    while (ptr != NULL) {
        if (compstr(ptr->user, username)) {
            counter = 1;
            if (ptr->post_ID == post_ID) {
                counter = 2;
                id = ID (header, username);
                int i = 0;
                while (ptr->like_list[i] != 0) {
                    if (ptr->like_list[i] == id) {
                        printf("You liked this post before!\n");
                        return 0;
                    }
                    i ++;
                }
                
                ptr->like_list = realloc(ptr->like_list, (i + 1) * sizeof(int));
                ptr->like_list[i] = id;
                ptr->like_list[i + 1] = 0;
                ptr->like ++;
                printf("You liked the %dth post of ", post_ID);
                printstr(name);
                printf("!\n");
                return 1;
            }
        }
        ptr = ptr->next;
    }

    if (counter == 0) {
        printf("The username is invalid!\n");
        return 0;
    }
    if (counter == 1) {
        printf ("The post ID is invalid!\n");
        return 0;
    }
}

int logout(char* username) {
    // deletes the username index 
    if (username == NULL) {
        printf ("You didn't sign up yet!\n");
        return 0;
    }
    else {
        printf ("You signed out successfuly!\n");
        free(username);
    }
}

int delete (int id, post_list* header, char* username) {
    // finds the post by geting the name and post_ID and deletes it
    post_list* ptr = header->next;
    while (ptr->next != NULL) {
        if (compstr(ptr->next->user, username) && ptr->next->post_ID == id ) {
            ptr->next = ptr->next->next;
            ptr = ptr->next;
            free(ptr->like_list);
            free(ptr->post);
            free(ptr->user);
            printf("Your post deleted successfuly!");
            return 1;
            
        }
        ptr = ptr->next;
    }
    return 0;
}

int info(char* username, post_list* header) {
    // finds the user by their username and prints all of their posts
     post_list* ptr = header->next;
    if (header == NULL || ptr == NULL) {
        printf("No one signed up yet!\n");
        return 0;
    }
    while (ptr != NULL) {
        if (compstr(ptr->user, username)) {
            while (!compstr(ptr->user, username)) {
                print_node(*ptr);
                ptr = ptr->next;
            }
            return 1;
        }
        ptr->next;
    }
    return 0;
}

int find_user(char* user, post_list* header) {
    // finds any user by their username and prints all of their posts
    post_list* ptr = header->next;
    while (ptr->next != NULL) {
        if (compstr(ptr->next->user, user)) {
            info(user, header);
            return 1;
        }
        ptr = ptr->next;
    } 
    return 0;
}