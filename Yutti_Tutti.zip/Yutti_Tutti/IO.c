#include "headers.h"

int compstr (char* str1, char* str2) {
    // compares two strings
    int i = 0;
    while (str1[i] != '\0' && str2[i] != '\0') {
        if(str1[i] != str2[i]) {
            return 0;
        }
        i++;
    }
    return 1;
}

void printstr (char* str) {
    // prints an string
    printf("%s", str);
    return;
}

void print_node (post_list node) {
    // prints a node of the linked list
    if (node.like != -1) {
        printf ("post : ");
        printstr (node.post);
        printf("\n");
        printf ("post ID : %d\n", node.post_ID);
        printf ("likes : %d\n", node.like);
    }
    else {
        printf("username : ");
        printstr (node.user);
        printf ("!\n");
    }
    return;
}

void save(post_list* header) {
    //saves the list of accounts and posts in two txt files.
    FILE* accounts = fopen(ACCOUNTS, "w");
    FILE* posts = fopen(POSTS, "w");
    post_list* ptr = header->next;
    post_list* ptr2 = header->next;
    int counter = 0;
    while (ptr != NULL) {
        if (ptr->like == -1) {
            ptr2 = ptr->next;
            while (ptr2 != NULL) {
                if (compstr(ptr2->user, ptr->user)) {
                    counter++;
                }
                else {
                    break;
                }
                ptr2 = ptr2->next;
            }
            fprintf(accounts, "%s %s %d\n", ptr->user, ptr->post, counter);
        }
        else {
            fprintf(posts, "%s %s %d\n", ptr->post, ptr->user, (sizeof(ptr->like_list) / sizeof(int)));
        }
        ptr = ptr->next;
    }
    fclose(accounts);
    fclose(posts);
}


    
