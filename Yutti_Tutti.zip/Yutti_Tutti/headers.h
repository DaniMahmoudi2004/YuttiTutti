#ifndef EOS

#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>

typedef struct POST {
    char* user;
    int id;
    char* post;
    int post_ID;
    int like;
    int* like_list;
    struct POST* next;
} post_list;

#define EOS ' '
#define EOL '\n'
#define TRUE 1
#define ORDER_NUM 9
#define ACCOUNTS "accounts.txt"
#define POSTS "posts.txt"

// IO

int compstr (char* str1, char* str2);
void printstr (char* str);
void print_node (post_list node);
void save (post_list* header);

// order

int order_type (char* order);
int ID (post_list* header, char* user);
int signup (char* user, char* password, post_list* dobby);
int login (char* name, char* password, post_list* header, char* username);
int post (char* post, char* username, post_list* header);
int like (int post_ID, char* name, char* username, post_list* header);
int delete (int id, post_list* header, char* username);
int info(char* username, post_list* header);
int find_user(char* user, post_list* header);

#endif